#!/usr/bin/env python3
"""DocumentOCR — minimal web UI backend.

Design constraints (mission):
  * zero new third-party web dependencies -> Python stdlib ``http.server`` only
  * reuse the existing OCR pipeline (``classes.detection.SuryaDetection``),
    never re-implement detection/recognition
  * llama.cpp is started with ``--parallel 1`` -> every OCR job is serialized
    with a global lock
  * per-request temp directory, always cleaned up (retention policy: 0 after
    the response is built)

Run:  python3 webui/server.py   (or ./run_ui.sh from the project root)
"""

from __future__ import annotations

import base64
import io
import json
import mimetypes
import os
import re
import shutil
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

# --------------------------------------------------------------------------
# Paths / imports. ``classes/detection.py`` calls load_dotenv() at import
# time, so the CWD must be the project root and it must be on sys.path.
# --------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = os.path.dirname(HERE)

os.chdir(APP_ROOT)
if APP_ROOT not in sys.path:
    sys.path.insert(0, APP_ROOT)

from loguru import logger  # noqa: E402  (already a project dependency)
from PIL import Image  # noqa: E402

from classes.detection import SuryaDetection  # noqa: E402
from config import settings  # noqa: E402

STATIC_DIR = os.path.join(HERE, "static")
TMP_ROOT = os.path.join(APP_ROOT, ".webui_tmp")

HOST = os.environ.get("WEBUI_HOST", "127.0.0.1")
PORT = int(os.environ.get("WEBUI_PORT", "8501"))
MAX_UPLOAD_BYTES = int(os.environ.get("WEBUI_MAX_UPLOAD_BYTES", str(25 * 1024 * 1024)))
PREVIEW_MAX_SIDE = 1500
PREVIEW_JPEG_QUALITY = 85
PDF_DPI = 200

# Engine location is derived from the same single source of truth the OCR
# pipeline uses (.env -> SURYA_INFERENCE_URL).
_OCR_URL = os.environ.get("SURYA_INFERENCE_URL", "http://127.0.0.1:8080/v1").rstrip("/")
HEALTH_URL = (_OCR_URL[: -len("/v1")] if _OCR_URL.endswith("/v1") else _OCR_URL) + "/health"
ENGINE_LABEL = "Surya 2.5 · llama.cpp"

try:  # PDF support is only advertised when the existing infra really works
    import pdf2image  # noqa: F401

    _HAS_PDF = shutil.which("pdftoppm") is not None
except Exception:  # pragma: no cover
    _HAS_PDF = False

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff", ".bmp"}
SUPPORTED_EXTENSIONS = sorted(IMAGE_EXTENSIONS | ({".pdf"} if _HAS_PDF else set()))

# --------------------------------------------------------------------------
# Model / pipeline state
# --------------------------------------------------------------------------
_model: SuryaDetection | None = None
_model_lock = threading.Lock()
_pipeline_lock = threading.Lock()  # llama.cpp runs with --parallel 1
_busy = False


def engine_ready(timeout: float = 2.0) -> bool:
    """Probe the llama.cpp server health endpoint (real check, no guessing)."""
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=timeout) as resp:
            if resp.status != 200:
                return False
            payload = json.loads(resp.read().decode("utf-8") or "{}")
            return payload.get("status") == "ok"
    except Exception:
        return False


def get_model() -> SuryaDetection:
    """Create the Surya pipeline once (loads DetectionPredictor + attaches to llama.cpp)."""
    global _model
    if _model is None:
        _model = SuryaDetection(
            output_dir=TMP_ROOT, save=True, detector_type="lines"
        )
    return _model


class _PathDataset:
    """Minimal stand-in for ``classes.dataset.ImagesDataset``.

    ``SuryaDetection.detect()`` only needs ``len()`` and ``get_data()``, so this
    keeps the UI on the exact same code path without touching the original
    dataset class.
    """

    def __init__(self, paths):
        self.data = list(paths)

    def get_data(self):
        return self.data

    def __len__(self):
        return len(self.data)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
_SAFE_NAME = re.compile(r"[^0-9A-Za-z\u0600-\u06FF._-]+")


def safe_stem(filename: str, fallback: str = "document") -> str:
    base = os.path.basename(filename or "").replace("\\", "/")
    base = base.rsplit("/", 1)[-1]
    stem, ext = os.path.splitext(base)
    stem = _SAFE_NAME.sub("_", stem).strip("._-") or fallback
    return stem[:80]


def preview_data_url(image_path: str) -> str:
    """Downscaled JPEG preview (used for PDF pages, which the browser cannot preview)."""
    with Image.open(image_path) as im:
        im = im.convert("RGB")
        im.thumbnail((PREVIEW_MAX_SIDE, PREVIEW_MAX_SIDE), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=PREVIEW_JPEG_QUALITY, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def image_size(image_path: str):
    with Image.open(image_path) as im:
        return list(im.size)


class HttpError(Exception):
    def __init__(self, status: int, code: str, message: str, hint: str = ""):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.hint = hint


def purge_stale_temp(max_age_s: int = 3600) -> None:
    """Remove leftovers from previously crashed runs (crash-safety net)."""
    if not os.path.isdir(TMP_ROOT):
        return
    now = time.time()
    for name in os.listdir(TMP_ROOT):
        path = os.path.join(TMP_ROOT, name)
        try:
            if now - os.path.getmtime(path) > max_age_s:
                shutil.rmtree(path, ignore_errors=True)
                logger.info(f"purged stale temp dir: {path}")
        except OSError:
            pass


def run_pipeline(upload_bytes: bytes, filename: str) -> dict:
    """Execute the real OCR pipeline for one uploaded document."""
    global _busy

    if not settings.ENABLE_RECOGNITION:
        raise HttpError(
            503,
            "recognition_disabled",
            "استخراج متن در تنظیمات غیرفعال شده است.",
            "ENABLE_RECOGNITION=true را در .env تنظیم کنید.",
        )

    ext = os.path.splitext(filename)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HttpError(
            415,
            "unsupported_type",
            "فرمت فایل پشتیبانی نمی‌شود.",
            "فرمت‌های مجاز: " + "، ".join(e.lstrip(".").upper() for e in SUPPORTED_EXTENSIONS),
        )

    if not engine_ready():
        raise HttpError(
            503,
            "engine_unavailable",
            "سرویس OCR در دسترس نیست.",
            "سرور پردازش اجرا نشده است. با اجرای run_ocr.sh یا run_ui.sh دوباره تلاش کنید.",
        )

    job_dir = os.path.join(TMP_ROOT, uuid.uuid4().hex)
    os.makedirs(job_dir, exist_ok=True)
    started = time.time()
    try:
        raw_path = os.path.join(job_dir, "upload" + ext)
        with open(raw_path, "wb") as f:
            f.write(upload_bytes)

        # ---- normalise / split the input into page images ------------------
        pages: list[str] = []
        kind = "image"
        if ext == ".pdf":
            kind = "pdf"
            from pdf_utils import pdf_to_images  # existing project helper

            try:
                pages = pdf_to_images(raw_path, os.path.join(job_dir, "pages"), dpi=PDF_DPI)
            except Exception as exc:  # noqa: BLE001
                logger.error(f"pdf conversion failed: {exc}\n{traceback.format_exc()}")
                raise HttpError(
                    422,
                    "pdf_failed",
                    "خواندن فایل PDF ناموفق بود.",
                    "از سالم بودن فایل و رمزگذاری‌نبودن آن مطمئن شوید.",
                ) from exc
            if not pages:
                raise HttpError(422, "pdf_empty", "این فایل PDF هیچ صفحه‌ای ندارد.")
        else:
            page_path = os.path.join(job_dir, "page_1.png")
            try:
                with Image.open(raw_path) as im:
                    im.convert("RGB").save(page_path, "PNG")
            except Exception as exc:  # noqa: BLE001
                logger.error(f"image decode failed: {exc}")
                raise HttpError(
                    422,
                    "unreadable_image",
                    "فایل تصویری قابل خواندن نیست.",
                    "ممکن است فایل خراب یا با پسوند نادرست ذخیره شده باشد.",
                ) from exc
            pages = [page_path]

        # ---- run the existing pipeline (serialized: --parallel 1) ----------
        with _pipeline_lock:
            _busy = True
            try:
                logger.info(
                    f"OCR job start: file={filename!r} kind={kind} pages={len(pages)}"
                )
                model = get_model()
                model.output_dir = job_dir  # per-request output dir (single-threaded)
                job_started = time.time()
                model.detect(_PathDataset(pages))
                job_elapsed = time.time() - job_started
            finally:
                _busy = False

        # ---- collect real engine output ------------------------------------
        result_pages = []
        failures = []
        for index, page_path in enumerate(pages, start=1):
            stem = os.path.splitext(os.path.basename(page_path))[0]
            ocr_path = os.path.join(job_dir, f"{stem}_ocr.json")
            if not os.path.isfile(ocr_path):
                failures.append(index)
                continue
            with open(ocr_path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            text = (payload.get("text") or "").strip()
            entry = {
                "page": index,
                "text": text,
                "blocks": len(payload.get("blocks") or []),
                "chars": len(text),
                "json": payload,
                "image_size": image_size(page_path),
            }
            if kind == "pdf":
                entry["preview"] = preview_data_url(page_path)
            result_pages.append(entry)

        if not result_pages:
            raise HttpError(
                503,
                "recognition_failed",
                "استخراج متن از سند ناموفق بود.",
                "اتصال سرور OCR یا سالم بودن تصویر را بررسی کنید.",
            )

        if failures:
            logger.error(f"recognition failed for pages: {failures}")

        # A blank result must never be reported as success.
        if all(not p["text"] for p in result_pages):
            raise HttpError(
                422,
                "no_text",
                "متنی در سند شناسایی نشد.",
                "تصویر ممکن است خالی، تار یا بدون متن قابل تشخیص باشد.",
            )

        elapsed_ms = int((time.time() - started) * 1000)
        logger.info(
            f"OCR job done: pages={len(result_pages)} "
            f"chars={sum(p['chars'] for p in result_pages)} in {elapsed_ms} ms"
        )
        return {
            "ok": True,
            "file": filename,
            "kind": kind,
            "page_count": len(pages),
            "elapsed_ms": elapsed_ms,
            "pipeline_ms": int(job_elapsed * 1000),
            "pages": result_pages,
        }
    finally:
        shutil.rmtree(job_dir, ignore_errors=True)


# --------------------------------------------------------------------------
# HTTP layer
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "DocumentOCR/1.0"
    protocol_version = "HTTP/1.1"

    # -- low level ------------------------------------------------------
    def log_message(self, fmt, *args):  # route stdlib access logs to loguru
        logger.debug("webui " + fmt % args)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: str) -> None:
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if path.endswith(".js"):
            ctype = "text/javascript; charset=utf-8"
        elif path.endswith(".css"):
            ctype = "text/css; charset=utf-8"
        elif path.endswith(".html"):
            ctype = "text/html; charset=utf-8"
        elif path.endswith(".ttf"):
            ctype = "font/ttf"
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def _static(self, rel: str) -> None:
        rel = rel.lstrip("/")
        target = os.path.abspath(os.path.join(STATIC_DIR, rel))
        if not target.startswith(os.path.abspath(STATIC_DIR) + os.sep):
            self._send_json(404, {"ok": False, "code": "not_found", "message": "مسیر یافت نشد."})
            return
        if not os.path.isfile(target):
            self._send_json(404, {"ok": False, "code": "not_found", "message": "فایل یافت نشد."})
            return
        self._send_file(target)

    # -- routes ---------------------------------------------------------
    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path in ("/", "/index.html"):
                self._static("index.html")
            elif path.startswith("/static/"):
                self._static(path[len("/static/"):])
            elif path == "/api/health":
                ready = engine_ready()
                self._send_json(
                    200,
                    {
                        "ok": True,
                        "service": "online",
                        "engine": {
                            "label": ENGINE_LABEL,
                            "ready": ready,
                            "endpoint": HEALTH_URL,
                        },
                        "busy": _busy,
                        "pdf": _HAS_PDF,
                        "max_upload_bytes": MAX_UPLOAD_BYTES,
                        "formats": [e.lstrip(".") for e in SUPPORTED_EXTENSIONS],
                    },
                )
            elif path == "/api/config":
                self._send_json(
                    200,
                    {
                        "ok": True,
                        "max_upload_bytes": MAX_UPLOAD_BYTES,
                        "formats": [e.lstrip(".") for e in SUPPORTED_EXTENSIONS],
                        "pdf": _HAS_PDF,
                    },
                )
            else:
                self._send_json(404, {"ok": False, "code": "not_found", "message": "مسیر یافت نشد."})
        except Exception as exc:  # noqa: BLE001
            logger.error(f"GET {path} failed: {exc}\n{traceback.format_exc()}")
            self._send_json(500, {"ok": False, "code": "server_error", "message": "خطای داخلی سرور."})

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/api/ocr":
            self._send_json(404, {"ok": False, "code": "not_found", "message": "مسیر یافت نشد."})
            return

        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0:
                raise HttpError(400, "empty_body", "فایلی ارسال نشده است.")
            if length > MAX_UPLOAD_BYTES:
                raise HttpError(
                    413,
                    "file_too_large",
                    f"حجم فایل بیشتر از حد مجاز ({MAX_UPLOAD_BYTES // (1024 * 1024)} مگابایت) است.",
                )

            raw_name = unquote(self.headers.get("X-Filename") or "document")
            filename = os.path.basename(raw_name.replace("\\", "/")) or "document"
            # the stored name is always rebuilt from a sanitized stem
            filename = safe_stem(filename) + os.path.splitext(filename)[1].lower()

            body = self.rfile.read(length)
            if len(body) != length:
                raise HttpError(400, "truncated_body", "فایل به‌طور کامل دریافت نشد.")

            payload = run_pipeline(body, filename)
            self._send_json(200, payload)

        except HttpError as err:
            logger.warning(f"OCR request rejected [{err.code}]: {err.message}")
            self._send_json(
                err.status,
                {"ok": False, "code": err.code, "message": err.message, "hint": err.hint},
            )
        except Exception as exc:  # noqa: BLE001
            logger.error(f"POST /api/ocr failed: {exc}\n{traceback.format_exc()}")
            self._send_json(
                500,
                {
                    "ok": False,
                    "code": "processing_failed",
                    "message": "پردازش سند با خطا مواجه شد.",
                    "hint": "جزئیات در لاگ سرور ثبت شده است.",
                },
            )


def main() -> None:
    os.makedirs(TMP_ROOT, exist_ok=True)
    purge_stale_temp()

    if not engine_ready(timeout=3):
        logger.warning(
            f"engine NOT reachable at {HEALTH_URL} — the UI will start, "
            "but OCR requests return 503 until the llama.cpp server is up."
        )
    else:
        logger.info(f"engine reachable at {HEALTH_URL}")

    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    httpd.daemon_threads = True
    logger.info(f"DocumentOCR UI listening on http://{HOST}:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("shutting down")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()

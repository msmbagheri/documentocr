/* =========================================================
   DocumentOCR — UI logic
   Talks to the local Python backend (webui/server.py) which
   runs the real Surya 2.5 + llama.cpp pipeline.
   ========================================================= */

(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const els = {
    dropzone: $("dropzone"),
    fileInput: $("file-input"),
    fileCard: $("file-card"),
    fileName: $("file-name"),
    fileMeta: $("file-meta"),
    removeFile: $("remove-file"),
    runBtn: $("run-btn"),
    runLabel: $("run-label"),
    runSpinner: $("run-spinner"),
    errorBox: $("error-box"),
    errorTitle: $("error-title"),
    errorHint: $("error-hint"),
    dismissError: $("dismiss-error"),
    engineStatus: $("engine-status"),
    engineValue: $("engine-value"),
    jobStatus: $("job-status"),
    jobValue: $("job-value"),
    formatsChip: $("formats-chip"),
    dropMeta: $("drop-meta"),
    previewStage: $("preview-stage"),
    previewCanvas: $("preview-canvas"),
    previewImg: $("preview-img"),
    previewPdf: $("preview-pdf"),
    placeholder: $("preview-placeholder"),
    zoomControls: $("zoom-controls"),
    zoomIn: $("zoom-in"),
    zoomOut: $("zoom-out"),
    zoomFit: $("zoom-fit"),
    zoomLabel: $("zoom-label"),
    pageTabs: $("page-tabs"),
    result: $("result"),
    resultBadge: $("result-badge"),
    ocrText: $("ocr-text"),
    textMeta: $("text-meta"),
    stats: $("stats"),
    jsonView: $("json-view"),
    jsonCode: $("json-code"),
    copyText: $("copy-text"),
    downloadTxt: $("download-txt"),
    copyJson: $("copy-json"),
    downloadJson: $("download-json"),
    toast: $("toast"),
  };

  const state = {
    file: null,
    objectUrl: null,
    busy: false,
    serverBusy: false,
    result: null,
    pageIndex: 0,
    zoom: 1,
    fitScale: 1,
    formats: ["png", "jpg", "jpeg", "webp", "tif", "tiff", "bmp"],
    maxBytes: 25 * 1024 * 1024,
    pdf: false,
  };

  /* ---------------- utilities ---------------- */

  const faNum = (n) => Number(n).toLocaleString("fa-IR");

  function formatBytes(bytes) {
    if (!bytes && bytes !== 0) return "—";
    const units = ["بایت", "کیلوبایت", "مگابایت", "گیگابایت"];
    let value = bytes;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024;
      unit += 1;
    }
    const rounded = unit === 0 ? Math.round(value) : Math.round(value * 10) / 10;
    return `${faNum(rounded)} ${units[unit]}`;
  }

  function formatDuration(ms) {
    if (ms == null) return "—";
    if (ms < 1000) return `${faNum(Math.round(ms))} میلی‌ثانیه`;
    const sec = ms / 1000;
    return `${faNum(Math.round(sec * 10) / 10)} ثانیه`;
  }

  let toastTimer = null;
  function toast(message) {
    els.toast.textContent = message;
    els.toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove("is-visible"), 2600);
  }

  function showError(message, hint) {
    els.errorTitle.textContent = message || "خطایی رخ داد.";
    if (hint) {
      els.errorHint.textContent = hint;
      els.errorHint.hidden = false;
    } else {
      els.errorHint.hidden = true;
    }
    els.errorBox.hidden = false;
  }

  function clearError() {
    els.errorBox.hidden = true;
    els.errorTitle.textContent = "";
    els.errorHint.textContent = "";
    els.errorHint.hidden = true;
  }

  function setJobState(kind, text) {
    els.jobStatus.dataset.state = kind;
    els.jobValue.textContent = text;
  }

  function setEngineState(ready) {
    els.engineStatus.dataset.state = ready ? "ready" : "offline";
    els.engineValue.textContent = ready ? "آماده به کار" : "در دسترس نیست";
  }

  function setBusy(busy) {
    state.busy = busy;
    els.runBtn.disabled = busy || !state.file || !state.engineReady;
    els.runSpinner.hidden = !busy;
    els.runLabel.textContent = busy ? "در حال استخراج متن از سند…" : "شروع OCR";
    els.fileInput.disabled = busy;
    els.removeFile.disabled = busy;
    els.runBtn.setAttribute("aria-busy", busy ? "true" : "false");
    if (busy) {
      setJobState("busy", "در حال پردازش");
    } else if (state.engineReady) {
      setJobState("idle", "آماده به کار");
    }
  }

  /* ---------------- health ---------------- */

  async function refreshHealth() {
    try {
      const res = await fetch("/api/health", { cache: "no-store" });
      if (!res.ok) throw new Error("health failed");
      const data = await res.json();

      state.engineReady = Boolean(data.engine && data.engine.ready);
      state.serverBusy = Boolean(data.busy);
      state.pdf = Boolean(data.pdf);
      state.maxBytes = data.max_upload_bytes || state.maxBytes;
      if (Array.isArray(data.formats) && data.formats.length) state.formats = data.formats;

      setEngineState(state.engineReady);
      applyFormatsHint();
      if (!state.busy) {
        els.runBtn.disabled = !state.file || !state.engineReady || state.serverBusy;
        if (state.serverBusy) setJobState("busy", "در حال پردازش");
        else setJobState("idle", "آماده به کار");
      }
      if (!state.engineReady) {
        showError(
          "سرویس OCR در دسترس نیست.",
          "سرور پردازش اجرا نشده است. با اجرای run_ocr.sh یا run_ui.sh دوباره تلاش کنید."
        );
      } else if (!state.serverBusy) {
        // only auto-clear engine errors, never a real job error
        if (els.errorTitle.textContent === "سرویس OCR در دسترس نیست.") clearError();
      }
    } catch (err) {
      setEngineState(false);
      els.runBtn.disabled = true;
    }
  }

  function applyFormatsHint() {
    const preferred = ["png", "jpg", "jpeg", "webp", "tiff", "tif", "bmp", "pdf"];
    const ordered = preferred.filter((f) => state.formats.includes(f));
    state.formats
      .filter((f) => !preferred.includes(f))
      .forEach((f) => ordered.push(f));

    const labels = ordered.map((f) => f.toUpperCase());
    els.formatsChip.textContent = state.pdf ? "تصویر و PDF" : "تصویر";
    els.dropMeta.textContent =
      `${labels.join(" · ")} — حداکثر ${formatBytes(state.maxBytes)}`;
    els.fileInput.accept = state.formats.map((f) => "." + f).join(",");
  }

  /* ---------------- file selection ---------------- */

  function extensionOf(name) {
    const i = name.lastIndexOf(".");
    return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
  }

  function looksLikePdf(file) {
    return extensionOf(file.name) === "pdf" || file.type === "application/pdf";
  }

  function clearPreview() {
    if (state.objectUrl) {
      URL.revokeObjectURL(state.objectUrl);
      state.objectUrl = null;
    }
    els.previewImg.hidden = true;
    els.previewImg.removeAttribute("src");
    els.previewPdf.hidden = true;
    els.previewPdf.removeAttribute("src");
    els.previewCanvas.classList.remove("has-image");
    els.placeholder.hidden = false;
    els.zoomControls.hidden = true;
    els.pageTabs.hidden = true;
    els.pageTabs.innerHTML = "";
  }

  function selectFile(file) {
    clearError();
    if (!file) return;

    const ext = extensionOf(file.name);
    if (!state.formats.includes(ext)) {
      showError(
        "فرمت فایل پشتیبانی نمی‌شود.",
        `فرمت‌های مجاز: ${state.formats.map((f) => f.toUpperCase()).join("، ")}`
      );
      resetFile();
      return;
    }
    if (file.size > state.maxBytes) {
      showError(
        "حجم فایل بیشتر از حد مجاز است.",
        `حداکثر حجم مجاز ${formatBytes(state.maxBytes)} است.`
      );
      resetFile();
      return;
    }
    if (file.size === 0) {
      showError("فایل خالی است.", "یک فایل معتبر انتخاب کنید.");
      resetFile();
      return;
    }

    state.file = file;
    state.result = null;
    state.pageIndex = 0;
    state.zoom = 1;
    els.result.hidden = true;

    els.fileCard.hidden = false;
    els.fileName.textContent = file.name;
    els.fileMeta.textContent = `${formatBytes(file.size)} · ${ext.toUpperCase()}`;
    els.dropzone.querySelector(".dropzone__title").textContent = "جایگزینی سند";
    els.dropzone.querySelector(".dropzone__sub").textContent = "فایل دیگری را رها یا انتخاب کنید";

    els.runBtn.disabled = !state.engineReady;
    renderPreview(file);
  }

  function resetFile() {
    state.file = null;
    state.result = null;
    els.fileInput.value = "";
    els.fileCard.hidden = true;
    els.fileName.textContent = "";
    els.fileMeta.textContent = "";
    els.runBtn.disabled = true;
    els.dropzone.querySelector(".dropzone__title").textContent = "تصویر سند را اینجا رها کنید";
    els.dropzone.querySelector(".dropzone__sub").textContent = "یا برای انتخاب از کامپیوتر کلیک کنید";
    clearPreview();
  }

  function renderPreview(file) {
    clearPreview();

    if (looksLikePdf(file)) {
      state.objectUrl = URL.createObjectURL(file);
      els.previewPdf.src = state.objectUrl;
      els.previewPdf.hidden = false;
      els.placeholder.hidden = true;
      els.zoomControls.hidden = true;
      return;
    }

    state.objectUrl = URL.createObjectURL(file);
    els.previewImg.onload = () => {
      els.previewImg.hidden = false;
      els.placeholder.hidden = true;
      els.zoomControls.hidden = false;
      state.zoom = 1;
      applyZoom();
    };
    els.previewImg.onerror = () => {
      showError("پیش‌نمایش تصویر ممکن نیست.", "ممکن است فایل خراب باشد.");
    };
    els.previewImg.src = state.objectUrl;
  }

  /* ---------------- zoom / pan ---------------- */

  function applyZoom() {
    const img = els.previewImg;
    if (!img || img.hidden || !img.naturalWidth) return;

    const stage = els.previewStage;
    const availW = Math.max(stage.clientWidth - 26, 80);
    const availH = Math.max(stage.clientHeight - 26, 80);
    const fit = Math.min(availW / img.naturalWidth, availH / img.naturalHeight);
    state.fitScale = fit;

    const width = Math.max(Math.round(img.naturalWidth * fit * state.zoom), 24);
    const height = Math.max(Math.round(img.naturalHeight * fit * state.zoom), 24);
    img.style.width = width + "px";
    img.style.height = height + "px";

    els.zoomLabel.textContent = `${faNum(Math.round(state.zoom * 100))}٪`;
    els.zoomFit.disabled = state.zoom === 1;
    els.zoomOut.disabled = state.zoom <= 0.5;
    els.zoomIn.disabled = state.zoom >= 4;
  }

  function setZoom(next) {
    state.zoom = Math.min(4, Math.max(0.5, Math.round(next * 100) / 100));
    applyZoom();
  }

  /* ---------------- OCR run ---------------- */

  async function runOCR() {
    if (!state.file || state.busy || !state.engineReady) return;

    clearError();
    setBusy(true);
    els.result.hidden = true;

    const started = performance.now();
    try {
      const res = await fetch("/api/ocr", {
        method: "POST",
        headers: {
          "Content-Type": state.file.type || "application/octet-stream",
          "X-Filename": encodeURIComponent(state.file.name),
        },
        body: state.file,
      });

      let data = null;
      try {
        data = await res.json();
      } catch (_) {
        throw { message: "پاسخ سرور قابل خواندن نبود.", hint: "لطفاً دوباره تلاش کنید." };
      }

      if (!res.ok || !data.ok) {
        throw {
          message: data.message || "پردازش سند ناموفق بود.",
          hint: data.hint || "",
        };
      }

      state.result = data;
      state.pageIndex = 0;
      renderResult(data, Math.round(performance.now() - started));
      toast("متن سند با موفقیت استخراج شد.");
    } catch (err) {
      if (err && err.message) {
        showError(err.message, err.hint || "");
      } else {
        showError("ارتباط با سرویس OCR برقرار نشد.", "اتصال سرور را بررسی کنید.");
      }
      refreshHealth();
    } finally {
      setBusy(false);
    }
  }

  /* ---------------- result rendering ---------------- */

  function renderResult(data, clientMs) {
    els.result.hidden = false;

    const pages = data.pages || [];
    const page = pages[state.pageIndex] || pages[0];

    els.resultBadge.textContent =
      data.kind === "pdf" && pages.length > 1
        ? `${faNum(pages.length)} صفحه پردازش شد`
        : "پردازش با موفقیت انجام شد";

    renderStats(data, page, clientMs);
    renderPage(state.pageIndex);

    if (pages.length > 1) {
      els.pageTabs.hidden = false;
      els.pageTabs.innerHTML = "";
      pages.forEach((p, i) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "page-tab";
        btn.textContent = `صفحه ${faNum(p.page)}`;
        btn.setAttribute("aria-selected", i === state.pageIndex ? "true" : "false");
        btn.addEventListener("click", () => {
          state.pageIndex = i;
          els.pageTabs.querySelectorAll(".page-tab").forEach((b, bi) => {
            b.setAttribute("aria-selected", bi === i ? "true" : "false");
          });
          renderPage(i);
          renderStats(data, pages[i], clientMs);
        });
        els.pageTabs.appendChild(btn);
      });
    } else {
      els.pageTabs.hidden = true;
    }

    if (!state.busy) {
      setJobState("idle", "آماده به کار");
    }

    requestAnimationFrame(() => {
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      els.result.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
    });
  }

  function renderPage(index) {
    const data = state.result;
    if (!data) return;
    const page = data.pages[index];
    if (!page) return;

    // text
    els.ocrText.innerHTML = "";
    const blocks = (page.json && page.json.blocks) || [];
    const pieces = [];
    blocks
      .slice()
      .sort((a, b) => (a.reading_order ?? 0) - (b.reading_order ?? 0))
      .forEach((block) => {
        const text = (block.text || "").trim();
        if (!text) return;
        const p = document.createElement("p");
        p.setAttribute("dir", "auto");
        p.textContent = text;
        els.ocrText.appendChild(p);
        pieces.push(text);
      });

    if (!pieces.length) {
      const p = document.createElement("p");
      p.className = "ocr-empty";
      p.textContent = page.text || "متنی برای نمایش وجود ندارد.";
      els.ocrText.appendChild(p);
      pieces.push(page.text || "");
    }

    els.textMeta.textContent = `${faNum(page.chars)} کاراکتر · ${faNum(page.blocks)} بلوک`;

    // json (real engine output, no synthetic data)
    els.jsonCode.innerHTML = highlightJson(page.json);

    // preview for PDF pages (browser cannot render PDF pages natively)
    if (page.preview) {
      els.previewPdf.hidden = true;
      els.previewImg.hidden = false;
      els.placeholder.hidden = true;
      els.zoomControls.hidden = false;
      if (state.objectUrl) {
        URL.revokeObjectURL(state.objectUrl);
        state.objectUrl = null;
      }
      state.zoom = 1;
      els.previewImg.onload = () => applyZoom();
      els.previewImg.src = page.preview;
    }
  }

  function renderStats(data, page, clientMs) {
    const elapsed = data.elapsed_ms ?? clientMs;
    const items = [
      { label: "نام فایل", value: data.file },
      { label: "تعداد بلوک‌های استخراج‌شده", value: faNum(page.blocks) },
      { label: "تعداد کاراکترها", value: faNum(page.chars) },
      { label: "زمان پردازش", value: formatDuration(elapsed) },
      { label: "وضعیت عملیات", value: "موفق", ok: true },
    ];
    if ((data.pages || []).length > 1) {
      items.splice(1, 0, {
        label: "صفحه",
        value: `${faNum(page.page)} از ${faNum(data.pages.length)}`,
      });
    }

    els.stats.innerHTML = "";
    items.forEach((item) => {
      const el = document.createElement("div");
      el.className = "stat";

      const label = document.createElement("span");
      label.className = "stat__label";
      label.textContent = item.label;

      const value = document.createElement("span");
      value.className = "stat__value" + (item.ok ? " stat__value--ok" : "");
      value.textContent = item.value;
      value.setAttribute("dir", "auto");

      el.appendChild(label);
      el.appendChild(value);
      els.stats.appendChild(el);
    });
  }

  function highlightJson(obj) {
    let text;
    try {
      text = JSON.stringify(obj, null, 2);
    } catch (_) {
      return "";
    }
    const escaped = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    return escaped.replace(
      /("(?:\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(?:true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g,
      (match) => {
        let cls = "j-num";
        if (/^"/.test(match)) {
          cls = /:$/.test(match) ? "j-key" : "j-str";
        } else if (/^(true|false)$/.test(match)) {
          cls = "j-bool";
        } else if (match === "null") {
          cls = "j-null";
        }
        // values may mix Persian and Latin: isolate them so bidi keeps the
        // string readable inside the LTR JSON document
        const inner = cls === "j-str" ? `<bdi>${match}</bdi>` : match;
        return `<span class="${cls}">${inner}</span>`;
      }
    );
  }

  /* ---------------- copy / download ---------------- */

  async function copyToClipboard(text) {
    if (!text) return false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) {
      /* fall through to legacy path */
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.top = "-1000px";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch (_) {
      return false;
    }
  }

  function currentPage() {
    if (!state.result) return null;
    return state.result.pages[state.pageIndex] || state.result.pages[0] || null;
  }

  function baseName() {
    const name = state.file ? state.file.name : "document";
    const dot = name.lastIndexOf(".");
    return dot > 0 ? name.slice(0, dot) : name;
  }

  function download(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function pageSuffix() {
    const data = state.result;
    if (!data) return "";
    return (data.pages || []).length > 1 ? `_page${state.pageIndex + 1}` : "";
  }

  /* ---------------- events ---------------- */

  els.dropzone.addEventListener("click", () => {
    if (!state.busy) els.fileInput.click();
  });

  els.dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (!state.busy) els.fileInput.click();
    }
  });

  els.fileInput.addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) selectFile(file);
  });

  ["dragenter", "dragover"].forEach((type) => {
    els.dropzone.addEventListener(type, (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!state.busy) els.dropzone.classList.add("is-dragover");
    });
  });

  ["dragleave", "dragend"].forEach((type) => {
    els.dropzone.addEventListener(type, (e) => {
      e.preventDefault();
      els.dropzone.classList.remove("is-dragover");
    });
  });

  els.dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    e.stopPropagation();
    els.dropzone.classList.remove("is-dragover");
    if (state.busy) return;
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) selectFile(file);
  });

  // page-level drop safety net (avoid the browser opening the file)
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => e.preventDefault());

  els.removeFile.addEventListener("click", () => {
    if (state.busy) return;
    resetFile();
    clearError();
  });

  els.runBtn.addEventListener("click", runOCR);
  els.dismissError.addEventListener("click", clearError);

  els.zoomIn.addEventListener("click", () => setZoom(state.zoom + 0.25));
  els.zoomOut.addEventListener("click", () => setZoom(state.zoom - 0.25));
  els.zoomFit.addEventListener("click", () => setZoom(1));

  els.previewStage.addEventListener(
    "wheel",
    (e) => {
      if (!els.previewImg.hidden && e.ctrlKey) {
        e.preventDefault();
        setZoom(state.zoom + (e.deltaY < 0 ? 0.15 : -0.15));
      }
    },
    { passive: false }
  );

  // drag to pan when zoomed in
  let pan = null;
  els.previewStage.addEventListener("pointerdown", (e) => {
    if (els.previewImg.hidden || state.zoom <= 1) return;
    pan = { x: e.clientX, y: e.clientY, left: els.previewStage.scrollLeft, top: els.previewStage.scrollTop };
    els.previewStage.setAttribute("dragging", "");
    els.previewStage.setPointerCapture(e.pointerId);
  });
  els.previewStage.addEventListener("pointermove", (e) => {
    if (!pan) return;
    els.previewStage.scrollLeft = pan.left - (e.clientX - pan.x);
    els.previewStage.scrollTop = pan.top - (e.clientY - pan.y);
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach((type) => {
    els.previewStage.addEventListener(type, () => {
      pan = null;
      els.previewStage.removeAttribute("dragging");
    });
  });

  if ("ResizeObserver" in window) {
    const ro = new ResizeObserver(() => applyZoom());
    ro.observe(els.previewStage);
  } else {
    window.addEventListener("resize", applyZoom);
  }

  els.copyText.addEventListener("click", async () => {
    const page = currentPage();
    if (!page) return;
    const ok = await copyToClipboard(page.text);
    toast(ok ? "متن در کلیپ‌بورد کپی شد." : "کپی متن ممکن نشد.");
  });

  els.downloadTxt.addEventListener("click", () => {
    const page = currentPage();
    if (!page) return;
    download(`${baseName()}${pageSuffix()}_ocr.txt`, page.text, "text/plain;charset=utf-8");
    toast("فایل TXT دانلود شد.");
  });

  els.copyJson.addEventListener("click", async () => {
    const page = currentPage();
    if (!page) return;
    const ok = await copyToClipboard(JSON.stringify(page.json, null, 2));
    toast(ok ? "JSON در کلیپ‌بورد کپی شد." : "کپی JSON ممکن نشد.");
  });

  els.downloadJson.addEventListener("click", () => {
    const page = currentPage();
    if (!page) return;
    download(
      `${baseName()}${pageSuffix()}_ocr.json`,
      JSON.stringify(page.json, null, 2),
      "application/json;charset=utf-8"
    );
    toast("فایل JSON دانلود شد.");
  });

  /* ---------------- boot ---------------- */

  applyFormatsHint();
  refreshHealth();
  setInterval(refreshHealth, 8000);
  window.addEventListener("focus", refreshHealth);
})();

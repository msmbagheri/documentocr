# general_ocr

This repository is created to make a general pipeline for adding new datasets to our OCR flow.

The current task is to generate to-be-refined labels on Kotob Darsi dataset.

## Installation

Tested on python 3.10

```pip install -r requirements.txt```

## Usage

Suppose you have download a book pdf from [here](http://www.chap.sch.ir/books)

Then use `pdf_utils.py` to convert it to a set of images.

Then set the images folder path as `DATA_PATH` in the `.env` file.

Change other vars in `.env` to suit your case, you can see an example already, make it similar to this.

Then run

```python main.py```

---

## Local Surya 2.5 recognition (llama.cpp, offline)

The pipeline reads text with Surya 2.5 served by a local `llama.cpp` server.

### One-time assets (already present)

| File | Size |
|---|---|
| `datasets/surya_gguf/surya-2.5-Q8_0.gguf` | 628,680,096 B |
| `datasets/surya_gguf/surya-2.5-mmproj.gguf` | 207,345,920 B |
| `datasets/surya_gguf/SHA256SUMS.txt` | checksums |

Surya text-detection weights are cached at `~/.cache/datalab/models/text_detection/2025_05_07` (74 MB).

### Start everything with one command

```bash
./run_ocr.sh
```

`run_ocr.sh` starts the server container (if not running), waits for `/health`, then runs `main.py`.

### Manual server start

```bash
docker run -d --name surya-llama --gpus all \
  -p 127.0.0.1:8080:8080 \
  -v /home/metadeep-one/projects/documentocr/datasets/surya_gguf:/models:ro \
  ghcr.io/ggml-org/llama.cpp:server-cuda \
  -m /models/surya-2.5-Q8_0.gguf \
  --mmproj /models/surya-2.5-mmproj.gguf \
  -ngl 99 --host 0.0.0.0 --port 8080 \
  --parallel 1 --ctx-size 16384 \
  --image-min-tokens 1024 \
  --alias datalab-to/surya-ocr-2.5 \
  --jinja --special
```

> `--image-min-tokens 1024` is required: without it Surya 2.5 loses short/small images
> (observed: empty or heavily corrupted output). `--alias` must be exactly
> `datalab-to/surya-ocr-2.5` — the model id Surya verifies via `/v1/models`.

### Outputs

Per input image in `JSONS_PATH`:

- `<stem>_lines.json` — detection boxes (unchanged contract)
- `<stem>_ocr.json` — recognized text: `text` + `blocks[]` (label, bbox, reading_order, html)

### Switches (`config.py` / `.env`)

| Var | Default | Meaning |
|---|---|---|
| `ENABLE_RECOGNITION` | `true` | run Surya recognition, write `*_ocr.json` |
| `ENABLE_PADDLE` | `false` | run the Paddle layout stage + layout merge (currently crashes on this host) |
| `SURYA_INFERENCE_BACKEND` | `llamacpp` | force llama.cpp backend |
| `SURYA_INFERENCE_URL` | `http://127.0.0.1:8080/v1` | attach to running server |

If the server is down, recognition logs `SpawnError: ... not reachable at /health`
per image and the pipeline still completes detection.
